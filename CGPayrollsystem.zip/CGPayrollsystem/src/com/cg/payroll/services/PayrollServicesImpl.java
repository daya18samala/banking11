package com.cg.payroll.services;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
public class PayrollServicesImpl implements PayrollServices {
	private PayrollDAOServices daoservices;
	private float annualTax;
	public PayrollServicesImpl() {
		daoservices=new PayrollDAOServicesImpl();
	}
	@Override
	public int acceptAssociateDetails(String firstName,String lastName, String emailId, String department,
			String designation, String pancard,float yearlyInvestmentUnder80C,
			float basicSalary, float epf,float companyPf,float accountNumber,String bankName, String ifscCode) {
		return daoservices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));	
	}
	
	@Override
	public float calculateNetSalary(int associateId) {
		if(getAssociateDetails(associateId)!=null) {
			Associate associate=getAssociateDetails(associateId);
			associate.getSalary().setPersonalAllowance(0.3f*associate.getSalary().getBasicSalary());
			associate.getSalary().setConveyenceAllowance(0.2f*associate.getSalary().getBasicSalary());
			associate.getSalary().setOtherAllowance(0.1f*associate.getSalary().getBasicSalary());
			associate.getSalary().setHra(0.25f*associate.getSalary().getBasicSalary());
			associate.getSalary().setGratuity(0.05f*associate.getSalary().getBasicSalary());
			associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getCompanyPf()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra());
			float annualSalary=12*associate.getSalary().getGrossSalary();
			if((associate.getYearlyInvestmentUnder80C()+12*associate.getSalary().getCompanyPf()+12*associate.getSalary().getEpf()<150000)) {
				if(annualSalary>=1000000) {
					annualTax=(annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getCompanyPf())-(12*associate.getSalary().getEpf()));
				}
					else if(annualSalary>=500000&&annualSalary<1000000) {
					annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getCompanyPf())-(12*associate.getSalary().getEpf())));
				}
				else if(annualSalary<500000 && annualSalary>=250000) {
				
					if(annualSalary-250000>associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getCompanyPf())+(12*associate.getSalary().getEpf()))
						annualTax=0.1f*(annualSalary-250000-(associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf())));
					else 
						annualTax=0;
				}
				else if(annualSalary<250000)
					annualTax=0;
			}
			else {
				if(annualSalary>=1000000) 
					annualTax=((annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000));
				else if(annualSalary>=500000&&annualSalary<1000000)
					annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000));
				else if(annualSalary<500000 && annualSalary>=250000)
					
					if(annualSalary-250000>associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getCompanyPf())+(12*associate.getSalary().getEpf()))
						annualTax=0.1f*(annualSalary-250000-(associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf())));
					else 
						annualTax=0;
				else
					annualTax=0;
			}
			associate.getSalary().setMonthlyTax(annualTax/12);
			associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
	return associate.getSalary().getNetSalary();
		}
	return 0;
}
		@Override
		public Associate getAssociateDetails(int associateId){
				return daoservices.getAssociate(associateId);	
		}
		@Override
		public Associate[] getAssociateDetails() {
				return daoservices.getAssociates();
		}
		@Override
		public boolean acceptAssociateDetailsForUpdate(int associateId, String firstName,String lastName, String emailId, String department,
			String designation, String pancard,float yearlyInvestmentUnder80C,
				float basicSalary, float epf,float companyPf,float accountNumber,String bankName, String ifscCode) {
			return daoservices.updateAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));	
		}
	/*	@Override
		public boolean delete(Associate associate) {
			return daoservices.deleteAssociate(associate);
		}*/
		@Override
		public boolean updateAssociate(int associateId,String firstName,String lastName, String emailId, String department,String designation, String pancard,float yearlyInvestmentUnder80C,
					float basicSalary, float epf,float companyPf,float accountNumber,String bankName, String ifscCode) {
			return daoservices.updateAssociate(new Associate(associateId,yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
		}
		@Override
		public boolean deleteAssociate(int associateId) {
			
			return daoservices.deleteAssociate(associateId);
			
		}
	
}
