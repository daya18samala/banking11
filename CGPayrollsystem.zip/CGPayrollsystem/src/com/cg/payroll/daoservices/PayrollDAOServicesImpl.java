package com.cg.payroll.daoservices;
import com.cg.payroll.beans.Associate;
public class PayrollDAOServicesImpl implements PayrollDAOServices{
	private static Associate[] associateList=new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;
	@Override
	public int insertAssociate(Associate associate){
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID();
	}
	@Override
	public boolean updateAssociate(Associate associate){
		for(int i=0;i<associateList.length;i++) 
			if (associateList[i]!=null && associate.getAssociateID()==associateList[i].getAssociateID()) {
					associateList[i]=associate;
					return true;
			}
			return false;
	}
	@Override
	public boolean deleteAssociate(int associateId){
		for(int i=0;i<associateList.length;i++)
			if (associateList[i]!=null && associateId==associateList[i].getAssociateID()) {
					associateList[i]=null;
					
					return true;
		}
		return false;
	}
	@Override
	public Associate getAssociate(int associateId){
		for(int i=0;i<associateList.length;i++) 
			if (associateList[i]!=null && associateId==associateList[i].getAssociateID()) 
					return associateList[i];
		return null;
	}
	@Override
	public Associate[] getAssociates(){	
		return associateList;
	}
	@Override
	public void updateList() {
		for(int i=0;i<associateList.length;i++) 
			if (associateList[i]==null ) 
				for(int j=i+1;j<associateList.length;j++)
				if(associateList[j]!=null) {
				associateList[i]=associateList[j];
				associateList[j]=null;
				i++;
			}		
		for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null)
				ASSOCIATE_IDX_COUNTER++;
		
	/*	if(ASSOCIATE_IDX_COUNTER+1>=0.7f*associateList.length) {
		public static Associate[] associateList1=new Associate[20];
			for(int i=0;i<associateList.length;i++) {
				associateList1[i]=associateList[i];
		}*/
	}
}
